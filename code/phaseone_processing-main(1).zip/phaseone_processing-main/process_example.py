from tools import read_iiq, write_image, extract_iiq_gps
from pathlib import Path

# Process folder and generate low-res images
path_raws = Path("/home/luroth/Documents/Local_workspace/PhaseOne/data/raws/20250925/")
path_processed = Path("/home/luroth/Documents/Local_workspace/PhaseOne/data/processed/")
path_processed.mkdir(parents=True, exist_ok=True)

extract_iiq_gps(path_raws, path_processed)

for file in path_raws.glob("*.IIQ"):

    low_res_img = read_iiq(file, downsample_factor=4)
    write_image(low_res_img, path_processed / file.name.replace(".IIQ", "_lowres.jpg"))