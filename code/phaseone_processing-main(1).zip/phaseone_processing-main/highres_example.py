import numpy as np

from tools import read_iiq, write_image
from pathlib import Path
import matplotlib.patches as patches
from matplotlib import pyplot as plt
import torch
import kornia

from skimage.restoration import (
    denoise_tv_chambolle,
    denoise_bilateral,
    denoise_wavelet,
    estimate_sigma,
)
from skimage import exposure

# Test high-res image with head detection
read_iiq_path = Path("/home/luroth/Documents/Local_workspace/PhaseOne/data/raws/P0002375.IIQ")
high_res_img = read_iiq(read_iiq_path, downsample_factor=1)
high_res_img = high_res_img / 2**16

sample = high_res_img[3000:3000+400, 3700:3700+600, :]
sample_eq = exposure.adjust_log(sample, 1.2)
sigma_est = estimate_sigma(sample, channel_axis=2, average_sigmas=True)

print(f'Estimated Gaussian noise standard deviation = {sigma_est}')
sample_denoise = denoise_wavelet(sample_eq, channel_axis=2, convert2ycbcr=True, sigma=0.06)

fig, axs = plt.subplots(3, 2, figsize=(20,30))
axs[0][1].imshow(sample[200:300, 0:100, :])
axs[0][0].imshow(sample)
axs[1][1].imshow(sample_eq[200:300, 0:100, :])
axs[1][0].imshow(sample_eq)
axs[2][1].imshow(sample_denoise[200:300, 0:100, :])
axs[2][0].imshow(sample_denoise)
plt.show()


import imageio
import numpy as np
imageio.imwrite("highres_sample.png", np.clip(sample_denoise * 255, 0, 255).astype('uint8'))

sample_eq = torch.tensor(imageio.imread("/home/luroth/Documents/Local_workspace/PhaseOne/data/raws/P0002375.jpeg"))[0:384, 0:384, :].permute(2,0,1) / 255.0


