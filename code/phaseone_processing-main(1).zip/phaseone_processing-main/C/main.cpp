#include <iostream>
#include <string>
#include <filesystem>
#include <P1Image.hpp>

std::string changeExtensionToJpeg(const std::string& filename, const std::string& suffix = "") {
    std::filesystem::path filePath(filename);
    std::string stem = filePath.stem().string();

    if (!suffix.empty()) {
        stem += "_" + suffix;
    }

    filePath.replace_filename(stem + ".jpeg");
    return filePath.string();
}

int main(int argc, const char** argv)
{
    // Check if input file argument is provided
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " <input_file> [x y width height] [crop_name]" << std::endl;
        std::cerr << "Example: " << argv[0] << " input-file.iiq" << std::endl;
        std::cerr << "Example with crop: " << argv[0] << " input-file.iiq 1000 2000 1024 768" << std::endl;
        std::cerr << "Example with crop and name: " << argv[0] << " input-file.iiq 1000 2000 1024 768 center_crop" << std::endl;
        return 1;
    }

    std::string inputFile = argv[1];

    // Parse crop parameters if provided
    bool useCrop = false;
    int cropX = 0, cropY = 0, cropWidth = 0, cropHeight = 0;
    std::string cropName = "";

    if (argc >= 6) {
        try {
            cropX = std::stoi(argv[2]);
            cropY = std::stoi(argv[3]);
            cropWidth = std::stoi(argv[4]);
            cropHeight = std::stoi(argv[5]);
            useCrop = true;

            // Check if crop name is provided
            if (argc == 7) {
                cropName = argv[6];
                std::cout << "Crop name: " << cropName << std::endl;
            }

            std::cout << "Crop parameters: x=" << cropX << ", y=" << cropY
                      << ", width=" << cropWidth << ", height=" << cropHeight << std::endl;
        }
        catch (const std::invalid_argument& e) {
            std::cerr << "Error: Invalid crop parameters. All crop values must be integers." << std::endl;
            return 1;
        }
        catch (const std::out_of_range& e) {
            std::cerr << "Error: Crop parameter values are out of range." << std::endl;
            return 1;
        }
    }
    else if (argc > 2 && argc < 6) {
        std::cerr << "Error: Crop requires exactly 4 parameters (x, y, width, height)" << std::endl;
        std::cerr << "Usage: " << argv[0] << " <input_file> [x y width height] [crop_name]" << std::endl;
        return 1;
    }
    else if (argc > 7) {
        std::cerr << "Error: Too many arguments provided." << std::endl;
        std::cerr << "Usage: " << argv[0] << " <input_file> [x y width height] [crop_name]" << std::endl;
        return 1;
    }

    std::string outputFile = changeExtensionToJpeg(inputFile, cropName);

    std::cout << "Input file: " << inputFile << std::endl;
    std::cout << "Output file: " << outputFile << std::endl;

    try {
        // Sensor data required by ImageSdk
        P1::ImageSdk::SetSensorProfilesLocation("./SensorProfiles");

        std::cout << "Opening raw file..." << std::endl;
        // Open the raw file using command line argument
        P1::ImageSdk::RawImage rawImage(inputFile);

        // Setup a convert config with the description about how to convert image into Rgb domain
        P1::ImageSdk::ConvertConfig config;
        config.SetOutputScale(1.0);
        config.SetLuminanceNoiseReductionAmount(0.5);
        config.SetColorNoiseReductionAmount(0.5);
        config.SetShadowRecovery(0.7f);
        config.SetHighlightRecovery(0.7f);
        config.SetOutputFormat(P1::ImageSdk::BitmapFormat::Rgb24);

        // Apply crop if specified
        if (useCrop) {
            std::cout << "Applying crop..." << std::endl;
            config.SetCrop(cropX, cropY, cropWidth, cropHeight);
        }

        std::cout << "Converting to RGB..." << std::endl;
        P1::ImageSdk::BitmapImage bitmap = rawImage.Convert(config);

        std::cout << "Writing Jpeg file..." << std::endl;

        P1::ImageSdk::JpegConfig jpeg;
        jpeg.quality = 100;
        jpeg.commonConfig.includePreview = false;
        P1::ImageSdk::JpegWriter(outputFile, bitmap, rawImage, jpeg);

        std::cout << "Successfully converted " << inputFile << " to " << outputFile << std::endl;
    }
    catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }
    catch (...) {
        std::cerr << "An unknown error occurred during conversion." << std::endl;
        return 1;
    }

    return 0;
}