Prerequisites:

On Windows you need:
    Windows 10 (x64)
    CMake 3.13 or later
    MSVC 2019 or later

To build:

mkdir build
cd build
cmake ..


To run (full image to TIFF):
./raw_to_tiff <path_to_file>

To run (cropped image to TIFF):
./raw_to_tiff <path_to_file> <x_start> <y_start> <x_witdh> <y_height>

To run (cropped image to TIFF, suffix):
./raw_to_tiff <path_to_file> <x_start> <y_start> <x_witdh> <y_height> <suffix>