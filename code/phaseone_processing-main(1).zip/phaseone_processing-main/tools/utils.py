import rawpy
import numpy as np
from PIL import Image
import imageio
import torch
import pandas as pd


# rawpy wrapper to read IIQ file and convert it to a low-res 8bit RGB image and a high-res 16bit RGB image
def read_iiq(file_path, downsample_factor=1):
    with rawpy.imread(str(file_path)) as raw:
        if downsample_factor != 1:
            # Process to get a low-res 8bit image
            rgb_low = raw.postprocess(
                use_camera_wb=True,
                half_size=True,
                output_bps=8,
            )
            # Resize to desired low-res shape
            img_low = Image.fromarray(rgb_low)
            img_low = img_low.resize((rgb_low.shape[1] // downsample_factor, rgb_low.shape[0] // downsample_factor))
            rgb_low_resized = np.array(img_low)
            return rgb_low_resized

        else:
            # Process to get a high-res 16bit image
            rgb_high = raw.postprocess(
                use_camera_wb=True,
                output_bps=16,
            )
            return rgb_high

import exiftool
et = exiftool.ExifToolHelper()

def extract_iiq_gps(path_raws, path_processed):
    files = path_raws.glob("*.IIQ")
    GPS_pos = et.get_tags(files, tags=["XMP:GPSFlightAltitude", "XMP:GPSLongitude", "XMP:GPSLatitude", "Camera:Yaw", "Camera:Pitch", "Camera:Roll"])
    df_pos = pd.DataFrame(GPS_pos)
    df_pos.SourceFile =  df_pos.SourceFile.str.split("/").str[-1]
    df_pos.to_csv(str(path_processed) + "/GPS_pos.csv", index=False)

def write_image(image_array, output_path):
    if image_array.dtype == np.uint8:
        imageio.imwrite(output_path, image_array)
    elif image_array.dtype == np.uint16:
        imageio.imwrite(output_path, image_array)
    else:
        raise ValueError("Unsupported image data type for writing.")




class ModelWrapper(torch.nn.Module):
    def __init__(self, model):
        super().__init__()
        self.model = model

    def forward(self, *args, **kwargs):
        # return only the predictions as in the original model
        return self.model(*args, **kwargs)[0]


# def load_wheathead_model() -> torch.nn.Module:
#     model = torch.hub.load("ultralytics/yolov5", "yolov5s", verbose=False, device="cpu")
#
#     model.names = {0: "wheat head"}
#     model.model = ModelWrapper(attempt_load("wheat_head_detection_model.pt"))
#
#     return model
